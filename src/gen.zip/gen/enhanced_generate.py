# src/gen/enhanced_generate.py - UNIVERSAL VERSION for any project structure
import argparse
import ast
import datetime
import json
import os
import pathlib
import re
import sys
import time
import traceback
from typing import Any, Dict, List, Optional, Set, Tuple

from .smart_change import (
    should_generate_tests, 
    prepare_for_generation, 
    finalize_generation)

__all__ = ["generate_all", "main"]

try:
    from .postprocess import extract_python_only, massage, validate_code
except Exception as _e:
    print(f"Warning: postprocess import failed: {_e}; using fallbacks")
    import ast as _ast
    import re as _re
    
    def extract_python_only(text: str) -> str:
        if "```" in text:
            blocks = _re.findall(r"```(?:python)?\s*(.*?)```", text, flags=_re.IGNORECASE|_re.DOTALL)
            return "\n\n".join(blocks) if blocks else text.replace("```","")
        return text
    
    def validate_code(code: str):
        if not code.strip(): return False, "empty output"
        if not _re.search(r"def test_", code): return False, "no test functions"
        try: _ast.parse(code); return True, ""
        except SyntaxError as e: return False, f"syntax error: {e}"
    
    def massage(code: str): return code

def _detect_framework_universal(analysis: Dict[str, Any]) -> str:
    """Enhanced framework detection for any Python framework - FIXED to trust analyzer results."""
    # CRITICAL FIX: Trust the analyzer's primary_framework result first
    primary_framework = analysis.get("primary_framework", "vanilla")
    framework_confidence = analysis.get("framework_confidence", {})
    
    # Only use our detection if analyzer result is unreliable (low confidence or vanilla with high other scores)
    if (primary_framework != "vanilla" and 
        framework_confidence.get(primary_framework, 0) > 20):
        print(f" Using analyzer-detected framework: {primary_framework} (confidence: {framework_confidence.get(primary_framework, 0)})")
        return primary_framework
    
    # Fallback to our detection logic if analyzer result is not reliable
    framework_scores = {
        "flask": 0,
        "fastapi": 0, 
        "django": 0,
        "starlette": 0,
        "tornado": 0,
        "bottle": 0,
        "pyramid": 0,
        "sanic": 0,
        "chalice": 0,
        "vanilla": 5  # Give vanilla a base score
    }
    
    # Check imports
    imports = analysis.get("imports", [])
    modules = analysis.get("modules", [])
    
    for imp in imports:
        for module in imp.get("modules", []):
            module_lower = module.lower()
            if "flask" in module_lower:
                framework_scores["flask"] += 10
            if "fastapi" in module_lower:
                framework_scores["fastapi"] += 10
            if "django" in module_lower:
                framework_scores["django"] += 10
            if "starlette" in module_lower:
                framework_scores["starlette"] += 8
            if "tornado" in module_lower:
                framework_scores["tornado"] += 8
            if "bottle" in module_lower:
                framework_scores["bottle"] += 8
            if "pyramid" in module_lower:
                framework_scores["pyramid"] += 8
            if "sanic" in module_lower:
                framework_scores["sanic"] += 8
            if "chalice" in module_lower:
                framework_scores["chalice"] += 8
    
    routes = analysis.get("routes", [])
    for route in routes:
        framework_hint = route.get("framework", "").lower()
        if framework_hint in framework_scores:
            framework_scores[framework_hint] += 5
    
    django_patterns = analysis.get("django_patterns", {})
    if any(len(django_patterns[key]) > 0 for key in django_patterns):
        framework_scores["django"] += 20
    
    if analysis.get("fastapi_routes"):
        framework_scores["fastapi"] += 15
    
    # Use analyzer's detected frameworks as additional signals
    detected_frameworks = analysis.get("detected_frameworks", {})
    for fw, score in detected_frameworks.items():
        if fw in framework_scores:
            framework_scores[fw] += score // 2  # Add half the analyzer's score
    
    primary_framework = max(framework_scores.items(), key=lambda x: x[1])
    
    # CRITICAL FIX: Only return vanilla if ALL framework scores are very low
    if primary_framework[1] < 10 and framework_scores["vanilla"] >= primary_framework[1]:
        print(f" Detected framework: vanilla (all scores < 10)")
        return "vanilla"
    
    print(f" Detected framework: {primary_framework[0]} (confidence: {primary_framework[1]})")
    return primary_framework[0]

def _create_universal_conftest(outdir: pathlib.Path, target_root: pathlib.Path, framework: str) -> str:
    """Create universal conftest.py for any project structure with framework-specific support."""
    from .conftest_text import conftest_text
    from .writer import write_text
    
    conftest_path = outdir / "conftest.py"
    
    # Get base conftest text
    base_conftest = conftest_text()
    
    # Enhanced universal conftest with framework-specific support
    framework_specific_setup = _get_framework_specific_setup(framework)
    
    universal_conftest = base_conftest + f'''

# UNIVERSAL fixtures for any project structure - FRAMEWORK: {framework}
import sys
import os

# Add project root to Python path for universal imports
PROJECT_ROOT = r"{target_root}"
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

{framework_specific_setup}

@pytest.fixture(scope="session", autouse=True)
def universal_coverage_setup():
    """UNIVERSAL setup for maximum coverage with real code execution."""
    # Set coverage optimization environment
    os.environ['COVERAGE_OPTIMIZATION'] = 'universal'
    os.environ['REAL_IMPORTS_ONLY'] = 'true'
    os.environ['TESTING_MAX_COVERAGE'] = 'true'
    
    # Universal framework auto-detection
    _setup_detected_frameworks()
    
    yield
    
    # Cleanup
    os.environ.pop('COVERAGE_OPTIMIZATION', None)
    os.environ.pop('REAL_IMPORTS_ONLY', None)

def _setup_detected_frameworks():
    """Auto-detect and setup frameworks for any project structure."""
    # Try to detect and import common project modules
    project_modules = ['app', 'main', 'application', 'server', 'api', 'backend', 'core', 'project']
    
    # Also try to detect project-specific modules from the structure
    try:
        # Look for Python files in project root to detect main modules
        for py_file in pathlib.Path(PROJECT_ROOT).glob("*.py"):
            module_name = py_file.stem
            if module_name not in project_modules and not module_name.startswith('_'):
                project_modules.append(module_name)
    except Exception:
        pass
    
    for module_name in project_modules:
        try:
            __import__(module_name)
            print(f" Detected and imported: {{module_name}}")
        except ImportError:
            continue

@pytest.fixture
def universal_sample_data():
    """UNIVERSAL sample data for comprehensive testing."""
    return {{
        'user': {{
            'username': 'testuser_universal',
            'email': 'universal_test@example.com',
            'password': 'UniversalPassword123!',
        }},
        'api_payloads': {{
            'create_user': {{
                'user': {{
                    'username': 'api_test_user',
                    'email': 'api_test@example.com',
                    'password': 'ApiTestPass123!',
                }}
            }},
            'login': {{
                'user': {{
                    'email': 'api_test@example.com',
                    'password': 'ApiTestPass123!',
                }}
            }},
        }},
        'edge_cases': {{
            'empty_string': '',
            'none_value': None,
            'zero': 0,
            'negative': -1,
            'large_number': 999999999999,
            'special_chars': r'!@#$%^&*()_+-=[]{{}}|;:,.<>?/\\~`',
            'unicode': '测试数据 🚀 émojis ñoños café ☕',
            'long_string': 'x' * 1000,
            'whitespace': '   ',
        }}
    }}

# UNIVERSAL test utilities
class UniversalTestUtils:
    """Universal utilities for achieving maximum coverage."""
    
    @staticmethod
    def setup_universal_imports():
        """Setup universal imports for any project structure."""
        print("🔍 UNIVERSAL: Setting up imports for any project structure")
    
    @staticmethod
    def generate_comprehensive_test_cases(target_name, target_type):
        """Generate comprehensive test cases for any target."""
        base_cases = [
            f"test_{{target_name}}_basic_functionality",
            f"test_{{target_name}}_edge_cases", 
            f"test_{{target_name}}_error_conditions",
            f"test_{{target_name}}_validation",
        ]
        
        if target_type in ['model', 'class']:
            base_cases.extend([
                f"test_{{target_name}}_creation",
                f"test_{{target_name}}_methods",
                f"test_{{target_name}}_properties",
            ])
        
        if target_type in ['api', 'route']:
            base_cases.extend([
                f"test_{{target_name}}_get",
                f"test_{{target_name}}_post", 
                f"test_{{target_name}}_put",
                f"test_{{target_name}}_delete",
            ])
        
        return base_cases
'''
    
    write_text(conftest_path, universal_conftest)
    return str(conftest_path)

def _get_framework_specific_setup(framework: str) -> str:
    """Get framework-specific setup code for conftest."""
    
    flask_setup = '''
# Flask-specific setup
try:
    from flask import Flask
    from flask.testing import FlaskClient
    HAS_FLASK = True
except ImportError:
    HAS_FLASK = False

@pytest.fixture
def flask_app():
    """Flask application fixture."""
    if HAS_FLASK:
        try:
            # Try to import actual Flask app
            try:
                from app import create_app
                app = create_app()
            except ImportError:
                try:
                    from application import create_app
                    app = create_app()
                except ImportError:
                    app = Flask(__name__)
                    app.config['TESTING'] = True
            return app
        except Exception:
            app = Flask(__name__)
            app.config['TESTING'] = True
            return app
    pytest.skip("Flask not available")

@pytest.fixture
def flask_client(flask_app):
    """Flask test client."""
    return flask_app.test_client()
'''
    
    fastapi_setup = '''
# FastAPI-specific setup
try:
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

@pytest.fixture
def fastapi_app():
    """FastAPI application fixture."""
    if HAS_FASTAPI:
        try:
            # Try to import actual FastAPI app
            try:
                from main import app
            except ImportError:
                try:
                    from app import app
                except ImportError:
                    app = FastAPI()
            return app
        except Exception:
            return FastAPI()
    pytest.skip("FastAPI not available")

@pytest.fixture
def fastapi_client(fastapi_app):
    """FastAPI test client."""
    return TestClient(fastapi_app)
'''
    
    django_setup = '''
# Django-specific setup
try:
    import django
    from django.test import TestCase, Client
    from django.conf import settings
    HAS_DJANGO = True
except ImportError:
    HAS_DJANGO = False

@pytest.fixture(scope='session')
def django_db_setup():
    """Django database setup."""
    if HAS_DJANGO:
        try:
            django.setup()
        except Exception:
            pass

@pytest.fixture
def django_client():
    """Django test client."""
    if HAS_DJANGO:
        return Client()
    pytest.skip("Django not available")
'''
    
    vanilla_setup = '''
# Vanilla Python setup - universal imports
import importlib
import sys

@pytest.fixture
def dynamic_import():
    """Dynamic import utility for any Python module."""
    def _importer(module_path):
        try:
            return importlib.import_module(module_path)
        except ImportError:
            pytest.skip(f"Module {module_path} not available")
    return _importer
'''
    
    framework_setups = {
        "flask": flask_setup,
        "fastapi": fastapi_setup, 
        "django": django_setup,
        "starlette": fastapi_setup,  # Similar to FastAPI
        "tornado": vanilla_setup,
        "bottle": flask_setup,  # Similar to Flask
        "pyramid": vanilla_setup,
        "sanic": vanilla_setup,
        "chalice": vanilla_setup,
        "vanilla": vanilla_setup
    }
    
    return framework_setups.get(framework, vanilla_setup)

def _generate_with_universal_retry(messages: List[Dict], max_attempts: int = 5) -> str:
    """Generate test code with UNIVERSAL retry logic."""
    from .openai_client import (APIError, RateLimitError,
                                create_chat_completion, create_client,
                                get_deployment_name)
    
    client = create_client()
    deployment = get_deployment_name()
    last_error = "unknown error"
    backoff_delays = [0, 2, 4, 8, 16]  # Exponential backoff
    
    for attempt in range(max_attempts):
        try:
            # Apply backoff delay
            if backoff_delays[attempt] > 0:
                print(f" Retrying generation in {backoff_delays[attempt]} seconds...")
                time.sleep(backoff_delays[attempt])
            
            # UNIVERSAL prompt enhancement for coverage on retry
            if attempt > 0:
                coverage_reminder = {
                    "role": "user",
                    "content": f" UNIVERSAL RETRY {attempt + 1}/{max_attempts}: Previous attempt failed. "
                               "CRITICAL: Generate tests for maximum COVERAGE that work with ANY PROJECT STRUCTURE. "
                               "Requirements:\n"
                               "1. Use absolute imports or proper relative imports\n"
                               "2. Handle any project structure (flat, nested, packages)\n"
                               "3. Generate 5-8 test methods per major target\n"
                               "4. Test ALL code paths: success, failure, edge cases\n"
                               "5. Include proper Python path setup\n"
                               "6. Test ALL public methods and properties\n"
                               "7. Ensure imports work regardless of project layout\n"
                }
                messages.append(coverage_reminder)
            
            # Make API call
            response_content = create_chat_completion(client, deployment, messages)
            
            if not response_content.strip():
                last_error = "Empty response from API"
                continue
            
            # Extract and validate Python code
            extracted_code = extract_python_only(response_content)
            if not extracted_code.strip():
                last_error = "No Python code found in response"
                continue
            
            # UNIVERSAL validation for coverage-focused code
            is_valid, validation_error = validate_code(extracted_code)
            if not is_valid:
                last_error = f"Code validation failed: {validation_error}"
                
                # Enhanced feedback based on error type
                if "no test functions" in validation_error.lower():
                    feedback_msg = {
                        "role": "user",
                        "content": "CRITICAL: Generated code lacks test functions. "
                                   "Generate 5-8 test methods per major target using 'def test_*' format. "
                                   "Each class should have tests for: creation, all methods, properties, "
                                   "edge cases, and error conditions."
                    }
                elif "syntax error" in validation_error.lower():
                    feedback_msg = {
                        "role": "user", 
                        "content": "Syntax error in generated code. Ensure:\n"
                                   "- Proper Python indentation\n"
                                   "- Variables declared before use\n" 
                                   "- Valid Python syntax in all test methods\n"
                                   "- All functions have proper docstrings\n"
                    }
                else:
                    feedback_msg = {
                        "role": "user",
                        "content": f"Code validation failed: {validation_error}. "
                                   "Generate valid Python code with maximum coverage target."
                    }
                
                messages.append(feedback_msg)
                continue
            
            # UNIVERSAL post-processing for coverage
            try:
                processed_code = massage(extracted_code)
                
                # Enhanced post-processing: Add universal optimization
                processed_code = _optimize_for_universal_coverage(processed_code)
                
                # Final validation
                final_valid, final_error = validate_code(processed_code)
                if final_valid:
                    return processed_code
                else:
                    print(f" Post-processing validation failed: {final_error}, using original")
                    return extracted_code
                    
            except Exception as process_error:
                print(f" Post-processing error: {process_error}, using original code")
                return extracted_code
                
        except RateLimitError as e:
            last_error = f"Rate limit exceeded: {e}"
            print(f" Rate limit hit on attempt {attempt + 1}, backing off...")
            
        except APIError as e:
            last_error = f"API error: {e}"
            if hasattr(e, 'status_code') and e.status_code in [400, 401, 403]:
                print(f" Non-retryable API error: {e}")
                break
            print(f" API error on attempt {attempt + 1}, retrying...")
            
        except Exception as e:
            last_error = f"API call failed: {e}"
            print(f" Generation attempt {attempt + 1} failed: {e}")
    
    # If all attempts failed, raise with detailed error
    raise RuntimeError(f" UNIVERSAL test generation failed after {max_attempts} attempts. Last error: {last_error}")

def _optimize_for_universal_coverage(code: str) -> str:
    """Optimize generated code for universal project compatibility."""
    lines = code.splitlines()
    optimized_lines = []
    
    # Adding universal optimization header
    optimized_lines.append('"""')
    optimized_lines.append('UNIVERSAL test suite - works with any project structure')
    optimized_lines.append('REAL IMPORTS ONLY - No stubs')
    optimized_lines.append('Generated for maximum compatibility and coverage')
    optimized_lines.append('"""')
    optimized_lines.append('')
    
    for line in lines:
        # Skip existing headers
        if line.strip().startswith('"""') and 'universal' in line.lower():
            continue
            
        optimized_lines.append(line)
        
        # Add universal optimization for test methods
        if 'def test_' in line and not line.strip().startswith('#'):
            # Add universal test method docstring
            test_name = line.split('def ')[1].split('(')[0]
            optimized_lines.append('    """UNIVERSAL test for maximum coverage."""')
    
    return '\n'.join(optimized_lines)

def _fix_imports_for_universal_compatibility(code: str, target_root: pathlib.Path, analysis: Dict[str, Any]) -> str:
    """Fix imports for universal project compatibility with enhanced Django support."""
    lines = code.splitlines()
    fixed_lines = []
    
    # Add universal import setup at the top
    fixed_lines.append('# UNIVERSAL IMPORT SETUP - Works with any project structure')
    fixed_lines.append('import sys')
    fixed_lines.append('import os')
    fixed_lines.append(f'sys.path.insert(0, r"{target_root}")')
    fixed_lines.append('')
    
    # Use the framework from analyzer to ensure consistency
    framework = analysis.get("primary_framework", "vanilla")
    if framework == "django":
        fixed_lines.append('# DJANGO SETUP - Critical for Django projects')
        fixed_lines.append('import django')
        fixed_lines.append('from django.conf import settings')
        fixed_lines.append('if not settings.configured:')
        fixed_lines.append('    # Auto-discover Django apps')
        fixed_lines.append('    installed_apps = [')
        fixed_lines.append('        "django.contrib.auth",')
        fixed_lines.append('        "django.contrib.contenttypes",')
        fixed_lines.append('        "django.contrib.sessions",')
        fixed_lines.append('        "django.contrib.admin",')
        fixed_lines.append('        "django.contrib.messages",')
        fixed_lines.append('    ]')
        fixed_lines.append('    ')
        fixed_lines.append('    # Discover project apps')
        fixed_lines.append('    import glob')
        fixed_lines.append('    search_root = r"{}"'.format(target_root))
        fixed_lines.append('    apps_py_files = glob.glob(f\'{search_root}/**/apps.py\', recursive=True)')
        fixed_lines.append('    ')
        fixed_lines.append('    for app_file in apps_py_files:')
        fixed_lines.append('        if "venv" not in app_file and "site-packages" not in app_file:')
        fixed_lines.append('            # Extract app name from path')
        fixed_lines.append('            app_path = app_file.replace(search_root, "").lstrip("/")')
        fixed_lines.append('            app_module = app_path.replace("/", ".").replace(".py", "")')
        fixed_lines.append('            app_name = app_module.rsplit(".", 1)[0]')
        fixed_lines.append('            if app_name not in installed_apps:')
        fixed_lines.append('                installed_apps.append(app_name)')
        fixed_lines.append('    ')
        fixed_lines.append('    # Add common app patterns')
        fixed_lines.append('    common_app_patterns = [')
        fixed_lines.append('        f\'{search_root}/*/models.py\',')
        fixed_lines.append('        f\'{search_root}/*/admin.py\',')
        fixed_lines.append('        f\'{search_root}/*/views.py\',')
        fixed_lines.append('    ]')
        fixed_lines.append('    ')
        fixed_lines.append('    for pattern in common_app_patterns:')
        fixed_lines.append('        for app_file in glob.glob(pattern, recursive=True):')
        fixed_lines.append('            if "venv" not in app_file and "site-packages" not in app_file:')
        fixed_lines.append('                app_dir = os.path.dirname(app_file)')
        fixed_lines.append('                app_dir = app_dir.replace(search_root, "").lstrip("/")')
        fixed_lines.append('                app_name = app_dir.replace("/", ".")')
        fixed_lines.append('                if app_name and app_name not in installed_apps and not app_name.startswith("."):')
        fixed_lines.append('                    installed_apps.append(app_name)')
        fixed_lines.append('    ')
        fixed_lines.append('    settings.configure(')
        fixed_lines.append('        DEBUG=True,')
        fixed_lines.append('        TESTING=True,')
        fixed_lines.append('        SECRET_KEY="test-secret-for-universal-django-tests",')
        fixed_lines.append('        DATABASES={"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}},')
        fixed_lines.append('        INSTALLED_APPS=installed_apps,')
        fixed_lines.append('        MIDDLEWARE=[],')
        fixed_lines.append('    )')
        fixed_lines.append('    django.setup()')
        fixed_lines.append('')
    
    # Get project structure info
    project_structure = analysis.get("project_structure", {})
    package_names = project_structure.get("package_names", [])
    module_paths = project_structure.get("module_paths", {})
    
    # Process existing imports
    in_import_section = True
    for line in lines:
        # Skip existing import setup
        if any(keyword in line for keyword in ['sys.path.insert', 'UNIVERSAL IMPORT SETUP', 'DJANGO SETUP']):
            continue
            
        # Fix relative imports for detected packages
        modified = False
        for package in package_names:
            # Fix: from utils import x → from myapp.utils import x
            if f'from {package}.' in line and not any(pkg in line for pkg in package_names if pkg != package):
                # This is already correct
                fixed_lines.append(line)
                modified = True
                break
            # Fix: import utils → import myapp.utils as utils
            elif f'import {package}' in line and package in package_names:
                fixed_lines.append(line)
                modified = True
                break
        
        if not modified:
            fixed_lines.append(line)
    
    return '\n'.join(fixed_lines)

def _gather_universal_context(target_root: pathlib.Path, analysis: Dict[str, Any],
                            focus_names: List[str], max_bytes: int = 120000) -> str:
    """Gather COMPLETE code context for universal project compatibility."""
    
    def read_file_safe(path: pathlib.Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return ""
    
    def build_universal_index(items: List[Dict], name_key: str) -> Dict[str, Tuple[str, int, int]]:
        index = {}
        for item in items or []:
            name = item.get(name_key)
            if name:
                class_name = item.get("class")
                if class_name:
                    name = f"{class_name}.{name}"
                
                file_path = item.get("file", "")
                start_line = item.get("lineno", 1)
                end_line = item.get("end_lineno", start_line)
                index[name] = (file_path, start_line, end_line)
        return index
    
    function_index = build_universal_index(analysis.get("functions", []), "name")
    class_index = build_universal_index(analysis.get("classes", []), "name")
    method_index = build_universal_index(analysis.get("methods", []), "name")
    route_index = build_universal_index(analysis.get("routes", []), "handler")
    
    # Collect ALL relevant files
    relevant_files = set()
    for target_name in focus_names:
        for index in [function_index, class_index, method_index, route_index]:
            if target_name in index:
                file_rel, _, _ = index[target_name]
                if file_rel:
                    relevant_files.add(file_rel)
                break
    
    # Also include files that import the target files
    imports_analysis = analysis.get("imports", [])
    for imp in imports_analysis:
        imp_file = imp.get("file", "")
        if imp_file and any(target_file in str(imp.get("modules", [])) for target_file in relevant_files):
            relevant_files.add(imp_file)
    
    # Include FULL file content for universal context
    context_parts = []
    current_size = 0
    
    # Add project structure info
    project_structure = analysis.get("project_structure", {})
    structure_info = f"""
# UNIVERSAL PROJECT STRUCTURE
# Root: {project_structure.get('root', 'Unknown')}
# Detected Packages: {', '.join(project_structure.get('package_names', []))}
# Total Modules: {len(project_structure.get('module_paths', {}))}
# Relevant Files: {len(relevant_files)}

"""
    context_parts.append(structure_info)
    current_size += len(structure_info)
    
    for file_rel in sorted(relevant_files):
        file_path = target_root / file_rel
        if file_path.exists():
            content = read_file_safe(file_path)
            if content:
                file_context = f"# FILE: {file_rel}\n# FULL CONTENT FOR UNIVERSAL COMPATIBILITY\n{content}\n\n{'='*80}\n\n"
                
                if current_size + len(file_context) > max_bytes:
                    # Include at least the beginning of each file
                    file_context = f"# FILE: {file_rel}\n# FIRST 1000 CHARACTERS\n{content[:1000]}...\n\n{'='*80}\n\n"
                
                context_parts.append(file_context)
                current_size += len(file_context)
    
    full_context = "".join(context_parts)
    
    coverage_header = f"""
# UNIVERSAL CODE CONTEXT FOR ANY PROJECT STRUCTURE
# Targets: {len(focus_names)} functions/classes/methods
# Files: {len(relevant_files)} source files  
# Strategy: Test ALL code paths with REAL IMPORTS
# Goal: Maximum line coverage and branch coverage
# UNIVERSAL COMPATIBILITY: Works with flat, nested, or package structures

"""
    
    full_context = coverage_header + full_context
    
    if len(full_context) > max_bytes:
        full_context = full_context[:max_bytes] + "\n# ... (truncated for context limits)"
    
    return full_context

def generate_all(analysis: Dict[str, Any], outdir: str = "tests/generated",
                focus_files: Optional[List[str]] = None):
    """Generate UNIVERSAL test suite for any project structure."""
    from .enhanced_analysis_utils import (compact_analysis, enhance_coverage_targeting,
                                          filter_by_files, infer_required_packages, 
                                          pip_install, prune_unavailable_targets)
    from .enhanced_prompt import build_prompt, files_per_kind, focus_for
    from .writer import update_manifest, write_text
    
    print(" UNIVERSAL test generation for ANY PROJECT STRUCTURE...")
    
    output_dir = pathlib.Path(outdir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    target_root = pathlib.Path(os.environ.get("TARGET_ROOT", "target"))
    if not target_root.exists():
        raise RuntimeError(f" Target directory not found: {target_root}")
    
    # CRITICAL FIX: Use analyzer's primary_framework directly for consistency
    framework = analysis.get("primary_framework", "vanilla")
    framework_confidence = analysis.get("framework_confidence", {})
    
    # Only use our detection if analyzer result is unreliable
    if framework == "vanilla" and framework_confidence.get("vanilla", 0) < 50:
        # Fallback to our detection with improved logic
        framework = _detect_framework_universal(analysis)
    
    print(f" Using framework: {framework.upper()} (confidence: {framework_confidence.get(framework, 'N/A')})")
    
    # UNIVERSAL: Ensure target root is in Python path
    if str(target_root) not in sys.path:
        sys.path.insert(0, str(target_root))
    
    conftest_path = _create_universal_conftest(output_dir, target_root, framework)
    print(f" Created universal conftest: {conftest_path}")
    
    should_generate, changed_files, deleted_files = should_generate_tests(str(target_root))
    
    if not should_generate:
        print(" No changes detected")
        return []
    
    prepare_for_generation(str(target_root), changed_files, deleted_files)
    
    force_generation = os.getenv("TESTGEN_FORCE", "").lower() in ["true", "1", "yes"]
    
    focus_file_set = set(focus_files or [])
    if not focus_file_set and not force_generation:
        focus_file_set = changed_files if changed_files else set()
    
    filtered_analysis, no_targets = filter_by_files(analysis, focus_file_set if focus_file_set else None)
    if no_targets:
        filtered_analysis = analysis
    
    compact = prune_unavailable_targets(compact_analysis(filtered_analysis))
    compact = enhance_coverage_targeting(compact)
    
    # Install ONLY external packages for real imports
    print(" Analyzing required packages...")
    required_packages = infer_required_packages(compact)
    
    if required_packages:
        print(f" Installing {len(required_packages)} external packages...")
        pip_install(required_packages)
    else:
        print(" No external packages need installation")
    
    total_targets = sum(len(compact.get(key, [])) 
                       for key in ["functions", "classes", "methods", "routes"])
    
    if total_targets == 0:
        raise RuntimeError(" No testable targets found")
    
    print(f" UNIVERSAL COVERAGE TARGETS:")
    print(f"    Functions: {len(compact.get('functions', []))}")
    print(f"    Classes: {len(compact.get('classes', []))}")
    print(f"    Methods: {len(compact.get('methods', []))}")
    print(f"    Routes: {len(compact.get('routes', []))}")
    print(f"    Total Targets: {total_targets}")
    print(f"    Expected Coverage: 95%+")
    print(f"    Project Structure: Universal compatibility")
    print(f"    Primary Framework: {framework.upper()}")
    
    has_routes = bool(compact.get("routes"))
    test_kinds = ["unit", "integ"]
    if has_routes:
        test_kinds.append("e2e")
    
    compact_json = json.dumps(compact, separators=(",", ":"))
    generated_files = []
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    
    for test_kind in test_kinds:
        num_files = files_per_kind(compact, test_kind)
        if num_files <= 0:
            continue
        
        print(f" Generating {num_files} {test_kind.upper()} test files for {framework.upper()} framework...")
        
        for file_index in range(num_files):
            try:
                focus_label, focus_names, shard_targets = focus_for(compact, test_kind, file_index, num_files)
                
                if not focus_names:
                    continue
                
                print(f"Generating {test_kind} test {file_index + 1}/{num_files} for {len(focus_names)} targets")
                
                context = _gather_universal_context(target_root, filtered_analysis, focus_names)
                
                prompt_messages = build_prompt(test_kind, compact_json, focus_label, 
                                              file_index, num_files, compact, context, framework)
                
                test_code = _generate_with_universal_retry(prompt_messages, max_attempts=3)
                
                # UNIVERSAL: Fix imports for any project structure
                test_code = _fix_imports_for_universal_compatibility(test_code, target_root, analysis)
                
                filename = f"test_{test_kind}_{timestamp}_{file_index + 1:02d}.py"
                file_path = output_dir / filename
                
                write_text(file_path, test_code)
                generated_files.append(str(file_path))
                print(f"   {filename} - {len(focus_names)} targets")
                
            except Exception as e:
                print(f"   Error generating {test_kind} test {file_index + 1}: {e}")
                traceback.print_exc()
    
    if generated_files and changed_files:
        finalize_generation(str(target_root), changed_files, generated_files)
    
    change_summary = {
        "added_or_modified": len(changed_files),
        "deleted": len(deleted_files),
        "total_analyzed": len(changed_files) + len(deleted_files),
        "coverage_target": "95%+",
        "universal_compatibility": True,
        "framework": framework,
        "project_structure": analysis.get("project_structure", {}).get("package_names", [])
    }
    update_manifest(output_dir, generated_files, change_summary)
    
    if generated_files:
        print(f" UNIVERSAL GENERATION COMPLETE: {len(generated_files)} test files")
        print(f" Expected Coverage: 95%+ with REAL IMPORTS")
        print(f" Framework Support: {framework.upper()}") 
        print(f" Targets Covered: {total_targets}")
        print(f" Project Structure: {len(analysis.get('project_structure', {}).get('package_names', []))} packages detected")
    
    return generated_files

def _validate_and_fix_test_code(code: str, filename: str) -> str:
    """Validate test code and attempt to fix common issues."""
    from .postprocess import massage, validate_code
    
    # First, try the normal massage process
    try:
        processed_code = massage(code)
        is_valid, error = validate_code(processed_code)
        
        if is_valid:
            return processed_code
        else:
            print(f" Massaged code still invalid for {filename}: {error}")
    except Exception as e:
        print(f" Error during massage for {filename}: {e}")
    
    # If massage failed, try basic fixes
    try:
        # Fix common indentation patterns
        lines = code.splitlines()
        fixed_lines = []
        
        for i, line in enumerate(lines):
            # Fix lines that should be indented after colons
            if i > 0 and line.strip() and not line.startswith(' ') and not line.startswith('\t'):
                prev_line = lines[i-1].rstrip()
                if prev_line.endswith(':') and not prev_line.startswith('#'):
                    line = '    ' + line
            
            fixed_lines.append(line)
        
        fixed_code = '\n'.join(fixed_lines)
        is_valid, error = validate_code(fixed_code)
        
        if is_valid:
            return fixed_code
        else:
            print(f" Basic fixes failed for {filename}: {error}")
    except Exception as e:
        print(f" Error during basic fixes for {filename}: {e}")
    
    # Last resort: return original code with warning
    print(f" All fixes failed for {filename}, using original code (may have syntax errors)")
    return f"# WARNING: This file may contain syntax errors\n# Generation system could not fix all issues\n\n{code}"

def main():
    """UNIVERSAL main entry point for any project structure."""
    parser = argparse.ArgumentParser(
        description="Generate UNIVERSAL pytest test suites for ANY PROJECT STRUCTURE",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
UNIVERSAL COMPATIBILITY EXAMPLES:
  python -m src.gen --target ./my_project
  python -m src.gen --target ./backend --force
  python -m src.gen --target ./app --outdir ./tests

SUPPORTED PROJECT STRUCTURES:
  - Flat structure (all files in root)
  - Nested structure (files in subdirectories) 
  - Package structure (with __init__.py files)
  - Mixed structures
  - Any Python project layout

SUPPORTED FRAMEWORKS:
  - Flask, FastAPI, Django, Starlette, Tornado
  - Bottle, Pyramid, Sanic, Chalice
  - Vanilla Python (no framework)
  - Any custom Python framework

FEATURES:
  - Automatic project structure detection
  - Universal import handling
  - Real imports only (no stubs)
  - 95%+ coverage target
  - Framework auto-detection
"""
    )
    
    parser.add_argument(
        "--target",
        default=os.environ.get("TARGET_ROOT", "target"),
        help="Path to Python project to analyze (default: %(default)s)"
    )
    
    parser.add_argument(
        "--outdir", 
        default="tests/generated",
        help="Output directory for generated tests (default: %(default)s)"
    )
    
    parser.add_argument(
        "--coverage-mode",
        choices=["normal", "maximum", "universal"],
        default=os.getenv("COVERAGE_MODE", "universal"),
        help="Coverage optimization mode (default: %(default)s)"
    )
    
    parser.add_argument(
        "--force",
        action="store_true", 
        help="Force regeneration"
    )
    
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Analyze code but don't generate tests"
    )
    
    args = parser.parse_args()
    
    # Set UNIVERSAL environment variables
    if args.force:
        os.environ["TESTGEN_FORCE"] = "true"
    os.environ["TARGET_ROOT"] = args.target
    os.environ["COVERAGE_MODE"] = args.coverage_mode
    os.environ["UNIVERSAL_COMPATIBILITY"] = "true"
    
    # Validate target
    target_path = pathlib.Path(args.target)
    if not target_path.exists():
        print(f" Target directory not found: {target_path}")
        return 1
    
    # UNIVERSAL: Find Python files recursively
    python_files = list(target_path.rglob("*.py"))
    if not python_files:
        print(f" No Python files found in: {target_path} (searched recursively)")
        return 1
    
    print(f" Found {len(python_files)} Python files in target directory")
    print(f" Project structure: Universal compatibility enabled")
    
    try:
        # Import UNIVERSAL analyzer
        try:
            from src.analyzer import analyze_python_tree
        except ImportError:
            try:
                from analyzer import analyze_python_tree  
            except ImportError:
                print(" Could not import analyzer module")
                return 1
        
        print(f"🔍 UNIVERSAL analysis for ANY PROJECT STRUCTURE in: {target_path}")
        analysis_result = analyze_python_tree(target_path)
        
        if args.dry_run:
            print(" UNIVERSAL DRY RUN - Project analysis complete")
            print(f" UNIVERSAL Analysis Summary:")
            print(f"    Functions: {len(analysis_result.get('functions', []))}")
            print(f"    Classes: {len(analysis_result.get('classes', []))}")
            print(f"    Methods: {len(analysis_result.get('methods', []))}")
            print(f"    Routes: {len(analysis_result.get('routes', []))}")
            print(f"    Modules: {len(analysis_result.get('modules', []))}")
            print(f"    Packages: {len(analysis_result.get('project_structure', {}).get('package_names', []))}")
            print(f"    Coverage Mode: {args.coverage_mode}")
            print(f"    Universal Compatibility:  ENABLED")
            return 0
        
        # Generate UNIVERSAL tests
        print(f" Starting UNIVERSAL test generation with {args.coverage_mode} coverage mode...")
        generated_files = generate_all(analysis_result, outdir=args.outdir)
        
        if generated_files:
            print(f"\n UNIVERSAL TEST GENERATION SUCCESSFUL!")
            print(f" UNIVERSAL Results:")
            print(f"    Generated: {len(generated_files)} test files")
            print(f"    Coverage Mode: {args.coverage_mode}")
            print(f"    Universal Compatibility:  ENABLED")
            print(f"    Targets Covered: {sum(len(analysis_result.get(key, [])) for key in ['functions', 'classes', 'methods', 'routes'])}")
            print(f"    Project Structure: Universal handling enabled")
            
            print(f" Run UNIVERSAL Tests:")
            print(f"   Basic: python -m pytest {args.outdir} -v")
            print(f"   Coverage: python -m pytest {args.outdir} --cov=. --cov-report=html")
            print(f"   Universal: PYTHONPATH={args.target} python -m pytest {args.outdir}")
            
            return 0
        else:
            print("\n  No tests generated")
            return 1
            
    except Exception as e:
        print(f"UNIVERSAL test generation failed: {e}")
        if os.getenv("TESTGEN_DEBUG", "0").lower() in ("1", "true"):
            traceback.print_exc()
        return 1

if __name__ == "__main__":
    exit(main())