# src/gen/enhanced_prompt.py - UPDATED with comprehensive Django fixes and FIXED dictionary initialization
import json
import os
import random
from typing import Any, Dict, List, Optional, Tuple

SYSTEM_MIN = (
    "Generate comprehensive pytest test code for the DETECTED FRAMEWORK.\n"
    "CRITICAL REQUIREMENTS:\n"
    " - Use REAL imports and REAL code execution - NO STUBS OR MOCKS for internal code\n"
    " - Test both success paths AND error conditions\n"
    " - Include edge cases: empty inputs, None values, invalid data\n"
    " - Test ALL public methods, properties, and class attributes\n"
    " - Generate 5-8 test methods per class/function for 95%+ coverage\n"
    " - Return ONLY Python code, no markdown\n"
    " - Use framework-specific testing patterns\n"
)

# CRITICAL FIX: Define vanilla framework instructions FIRST to prevent KeyError
VANILLA_INSTRUCTIONS = {
    "unit": (
        "Generate COMPREHENSIVE UNIT tests for vanilla Python code:\n"
        "CRITICAL REQUIREMENTS:\n"
        "1. Test ALL functions, classes, and methods with real imports\n"
        "2. Use pytest fixtures for setup and teardown\n"
        "3. Test edge cases: None, empty strings, zero, negative numbers\n"
        "4. Test error conditions and exception handling\n"
        "5. Use parametrize for multiple input scenarios\n"
        "6. Ensure 95%+ line and branch coverage\n"
        "7. Use real imports only - no stubs for internal code\n"
        "\n"
        "TESTING PATTERNS:\n"
        "- Arrange-Act-Assert for clear test structure\n"
        "- One test per behavior or scenario\n"
        "- Comprehensive input validation testing\n"
        "- Error condition testing with expected exceptions\n"
    ),
    "integ": (
        "Generate COMPREHENSIVE INTEGRATION tests for vanilla Python code:\n"
        "CRITICAL REQUIREMENTS:\n"
        "1. Test interactions between multiple modules and components\n"
        "2. Use real imports and actual code execution\n"
        "3. Test complete workflows and data flows\n"
        "4. Include error scenarios and recovery paths\n"
        "5. Test with realistic data and edge cases\n"
        "6. Ensure proper setup and teardown of test state\n"
        "7. Verify integration points and data consistency\n"
        "\n"
        "INTEGRATION PATTERNS:\n"
        "- Test multi-step processes end-to-end\n"
        "- Verify data transformation across components\n"
        "- Test error propagation and handling\n"
        "- Validate state changes across system boundaries\n"
    ),
    "e2e": (
        "Generate COMPREHENSIVE END-TO-END tests for vanilla Python applications:\n"
        "CRITICAL REQUIREMENTS:\n"
        "1. Test complete user workflows from start to finish\n"
        "2. Use real system components and actual execution\n"
        "3. Include all system layers and integration points\n"
        "4. Test with production-like data and scenarios\n"
        "5. Verify final outcomes and system state\n"
        "6. Include error scenarios and exception paths\n"
        "7. Ensure proper test isolation and cleanup\n"
        "\n"
        "E2E TESTING PATTERNS:\n"
        "- Complete business process testing\n"
        "- Data flow validation across entire system\n"
        "- Error handling and recovery testing\n"
        "- Performance and scalability under realistic loads\n"
    )
}

# Enhanced framework-specific test instructions with COMPREHENSIVE Django fixes
FRAMEWORK_INSTRUCTIONS = {
    "vanilla": VANILLA_INSTRUCTIONS,  # Define vanilla FIRST to prevent KeyError
    "django": {
        "unit": (
            "Generate COMPREHENSIVE UNIT tests for Django application:\n"
            "CRITICAL DJANGO REQUIREMENTS:\n"
            "1. EVERY test that touches database MUST use @pytest.mark.django_db\n"
            "2. Use proper RequestFactory with middleware setup\n"
            "3. For file uploads: use SimpleUploadedFile, NEVER set request.FILES directly\n"
            "4. Use django.test.Client for views requiring sessions/middleware\n"
            "5. Setup proper test data using factories or direct model creation\n"
            "6. Include ALL required model relationships in test setup\n"
            "7. Use override_settings for MEDIA_ROOT, DATABASES, etc.\n"
            "8. Ensure all URL reverses use existing URL patterns\n"
            "\n"
            "DATABASE TESTING:\n"
            "- ALWAYS use @pytest.mark.django_db for database operations\n"
            "- Create complete test data hierarchy (users, profiles, related objects)\n"
            "- Use transactions or setUp/tearDown for data isolation\n"
            "- Test model methods, signals, and relationships\n"
            "\n"
            "MIDDLEWARE SETUP:\n"
            "- Use RequestFactory with proper middleware initialization\n"
            "- For session-dependent views, use django.test.Client\n"
            "- Initialize middleware with get_response=lambda x: x\n"
            "\n"
            "FILE UPLOADS:\n"
            "- Use SimpleUploadedFile for file uploads\n"
            "- NEVER set request.FILES directly (it's read-only)\n"
            "- Use override_settings for MEDIA_ROOT during file tests\n"
            "\n"
            "TEST DATA:\n"
            "- Create complete user profiles with all required relationships\n"
            "- Ensure merchant users have merchant profiles\n"
            "- Create categories, subcategories before product tests\n"
            "- Use unique usernames/emails to avoid integrity errors\n"
            "\n"
            "URLS AND VIEWS:\n"
            "- Check that URL names exist in the project\n"
            "- Use Client().get()/post() for view testing with sessions\n"
            "- Test both GET and POST methods for form views\n"
            "\n"
            "EXAMPLE PATTERNS:\n"
            "@pytest.mark.django_db\n"
            "def test_example():\n"
            "    # Setup complete test data\n"
            "    user = CustomUser.objects.create(username='test', user_type=3)\n"
            "    MerchantUser.objects.create(user=user, ...)\n"
            "    \n"
            "    # Test with proper client\n"
            "    client = Client()\n"
            "    response = client.get('/url/')\n"
            "\n"
            "For RequestFactory with middleware:\n"
            "factory = RequestFactory()\n"
            "request = factory.post('/url/', data, format='multipart')\n"
            "request.user = user\n"
            "\n"
            "For file uploads:\n"
            "from django.core.files.uploadedfile import SimpleUploadedFile\n"
            "file = SimpleUploadedFile('test.jpg', b'content', 'image/jpeg')\n"
            "response = client.post('/upload/', {'file': file})\n"
        ),
        "integ": (
            "Generate COMPREHENSIVE INTEGRATION tests for Django application:\n"
            "CRITICAL INTEGRATION REQUIREMENTS:\n"
            "1. ALL integration tests MUST use @pytest.mark.django_db\n"
            "2. Use django.test.Client for complete request/response cycle\n"
            "3. Setup COMPLETE test data hierarchies\n"
            "4. Test multi-step workflows and user journeys\n"
            "5. Include authentication and session testing\n"
            "6. Test file uploads with SimpleUploadedFile\n"
            "7. Verify database state changes after operations\n"
            "8. Test error handling and edge cases\n"
            "\n"
            "TEST DATA HIERARCHY:\n"
            "- Create users with proper user_type and profiles\n"
            "- Create categories and subcategories before products\n"
            "- Create merchant users with complete merchant profiles\n"
            "- Use unique data to avoid constraint violations\n"
            "\n"
            "WORKFLOW TESTING:\n"
            "- Test complete user registration → login → action flows\n"
            "- Test file upload → processing → result workflows\n"
            "- Test product creation → media upload → inventory management\n"
            "- Test admin login → CRUD operations → logout\n"
            "\n"
            "FILE HANDLING:\n"
            "- Use SimpleUploadedFile for all file upload tests\n"
            "- Use override_settings(MEDIA_ROOT=tempfile.mkdtemp())\n"
            "- Clean up files after tests\n"
            "\n"
            "AUTHENTICATION:\n"
            "- Test login/logout workflows\n"
            "- Test session persistence\n"
            "- Test access control and permissions\n"
            "\n"
            "EXAMPLE INTEGRATION TEST:\n"
            "@pytest.mark.django_db\n"
            "def test_complete_product_workflow():\n"
            "    client = Client()\n"
            "    \n"
            "    # 1. Create merchant user\n"
            "    user = CustomUser.objects.create(username='merchant', user_type=3)\n"
            "    merchant = MerchantUser.objects.create(user=user, ...)\n"
            "    \n"
            "    # 2. Create category\n"
            "    category = Categories.objects.create(title='Electronics')\n"
            "    \n"
            "    # 3. Login\n"
            "    client.force_login(user)\n"
            "    \n"
            "    # 4. Create product\n"
            "    response = client.post('/product/create/', {\n"
            "        'title': 'Test Product',\n"
            "        'category': category.id,\n"
            "        ...\n"
            "    })\n"
            "    \n"
            "    # 5. Verify product creation\n"
            "    assert Product.objects.count() == 1\n"
            "    assert response.status_code == 302\n"
        ),
        "e2e": (
            "Generate COMPREHENSIVE END-TO-END tests for Django application:\n"
            "CRITICAL E2E REQUIREMENTS:\n"
            "1. ALL E2E tests MUST use @pytest.mark.django_db\n"
            "2. Use django.test.Client for browser-like testing\n"
            "3. Test complete user journeys across multiple views\n"
            "4. Include session state and authentication flows\n"
            "5. Test file uploads and downloads\n"
            "6. Verify database state throughout workflows\n"
            "7. Test error handling and user feedback\n"
            "8. Include edge cases and boundary conditions\n"
            "\n"
            "COMPLETE WORKFLOWS:\n"
            "- User registration → email verification → login → dashboard\n"
            "- Product search → add to cart → checkout → payment\n"
            "- Admin login → user management → content creation → logout\n"
            "- File upload → processing → display → download\n"
            "\n"
            "TEST DATA MANAGEMENT:\n"
            "- Create comprehensive test datasets\n"
            "- Use transactions for data isolation\n"
            "- Clean up test data after execution\n"
            "\n"
            "SESSION AND STATE:\n"
            "- Test session persistence across requests\n"
            "- Test authentication state maintenance\n"
            "- Test cookie and session storage\n"
            "\n"
            "FILE OPERATIONS:\n"
            "- Test complete file upload workflows\n"
            "- Verify file storage and retrieval\n"
            "- Test file validation and error handling\n"
        )
    }
}

# CRITICAL FIX: Safe initialization for other frameworks without circular reference
OTHER_FRAMEWORKS = ["flask", "fastapi", "starlette", "tornado", "bottle", "pyramid", "sanic", "chalice"]
for framework in OTHER_FRAMEWORKS:
    if framework not in FRAMEWORK_INSTRUCTIONS:
        # Use get() method to safely reference vanilla instructions
        FRAMEWORK_INSTRUCTIONS[framework] = FRAMEWORK_INSTRUCTIONS.get("vanilla", VANILLA_INSTRUCTIONS)

MAX_TEST_FILES = {"unit": 4, "integ": 4, "e2e": 2}

# Enhanced framework scaffolds with COMPREHENSIVE Django fixes
def _get_framework_scaffold(framework: str) -> str:
    """Get framework-specific test scaffold with COMPREHENSIVE fixes."""
    
    universal_scaffold = '''
"""
UNIVERSAL test suite - REAL IMPORTS ONLY
Supports any Python framework and project structure
"""
import pytest
import sys
import os
import importlib
import tempfile
from unittest.mock import patch, Mock

# UNIVERSAL IMPORT SETUP - Works with any project structure
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Universal import helper
def safe_import(module_path, class_name=None):
    """Safely import any module or class."""
    try:
        module = importlib.import_module(module_path)
        if class_name:
            return getattr(module, class_name)
        return module
    except (ImportError, AttributeError) as e:
        pytest.skip(f"Required import not available: {module_path}.{class_name if class_name else ''} - {e}")

# Universal test utilities
class UniversalTestUtils:
    """Utilities for universal test compatibility."""
    
    @staticmethod
    def setup_imports():
        """Setup imports for any project structure."""
        print(" UNIVERSAL: Setting up imports for any project structure")
    
    @staticmethod  
    def generate_test_cases(target_name, target_type):
        """Generate comprehensive test cases for any target."""
        return [
            f"test_{{target_name}}_basic_functionality",
            f"test_{{target_name}}_edge_cases",
            f"test_{{target_name}}_error_conditions",
            f"test_{{target_name}}_validation_rules",
        ]
'''

    framework_scaffolds = {
        "django": universal_scaffold + '''
# COMPREHENSIVE Django-specific imports and setup
import django
from django.test import TestCase, Client, RequestFactory
from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile
from django.contrib.sessions.middleware import SessionMiddleware
from django.contrib.auth.middleware import AuthenticationMiddleware
from django.contrib.messages.middleware import MessageMiddleware
import tempfile
import os

# Ensure Django is configured for testing
if not settings.configured:
    # Create temporary media root for file tests
    TEST_MEDIA_ROOT = tempfile.mkdtemp()
    
    settings.configure(
        DEBUG=True,
        TESTING=True,
        SECRET_KEY='test-secret-key-for-universal-django-tests-' + str(os.getpid()),
        DATABASES={
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': ':memory:',
            }
        },
        INSTALLED_APPS=[
            'django.contrib.auth',
            'django.contrib.contenttypes',
            'django.contrib.sessions',
            'django.contrib.admin',
            'django.contrib.messages',
            'DjangoEcommerceApp',  # Your app name
        ],
        MIDDLEWARE=[
            'django.middleware.security.SecurityMiddleware',
            'django.contrib.sessions.middleware.SessionMiddleware',
            'django.middleware.common.CommonMiddleware',
            'django.middleware.csrf.CsrfViewMiddleware',
            'django.contrib.auth.middleware.AuthenticationMiddleware',
            'django.contrib.messages.middleware.MessageMiddleware',
        ],
        ROOT_URLCONF='DjangoEcommerceApp.urls',  # Your URL config
        MEDIA_ROOT=TEST_MEDIA_ROOT,
        MEDIA_URL='/media/',
        BASE_URL='http://testserver',
        USE_TZ=True,
    )
    django.setup()

HAS_DJANGO = True

# CRITICAL: Apply django_db mark to ALL tests that need database
pytestmark = pytest.mark.django_db

# COMPREHENSIVE Django fixtures
@pytest.fixture
def django_client():
    """Django test client with session support."""
    return Client()

@pytest.fixture
def request_factory():
    """RequestFactory with proper middleware setup."""
    return RequestFactory()

@pytest.fixture
def authenticated_request(request_factory):
    """Request with authenticated user and middleware."""
    def _create_request(user=None, method='GET', data=None):
        if method.upper() == 'POST':
            request = request_factory.post('/', data or {})
        else:
            request = request_factory.get('/')
        
        # Add user if provided
        if user:
            request.user = user
        
        # Add session middleware
        session_middleware = SessionMiddleware(lambda x: x)
        session_middleware.process_request(request)
        request.session.save()
        
        # Add auth middleware
        auth_middleware = AuthenticationMiddleware(lambda x: x)
        auth_middleware.process_request(request)
        
        # Add message middleware  
        message_middleware = MessageMiddleware(lambda x: x)
        message_middleware.process_request(request)
        
        return request
    return _create_request

@pytest.fixture
def test_media_root():
    """Temporary media root for file upload tests."""
    media_root = tempfile.mkdtemp()
    with override_settings(MEDIA_ROOT=media_root):
        yield media_root
    # Cleanup
    import shutil
    shutil.rmtree(media_root, ignore_errors=True)

@pytest.fixture
def sample_uploaded_file():
    """Sample uploaded file for testing."""
    return SimpleUploadedFile(
        "test.jpg",
        b"file_content",
        content_type="image/jpeg"
    )

# TEST DATA FACTORIES
@pytest.fixture
def create_test_user():
    """Factory for creating test users with profiles."""
    def _create_user(username, email, user_type, **kwargs):
        from DjangoEcommerceApp.models import CustomUser, MerchantUser, StaffUser, CustomerUser
        
        # Create user
        user = CustomUser.objects.create(
            username=username,
            email=email,
            user_type=user_type,
            **kwargs
        )
        
        # Create profile based on user type
        if user_type == 3:  # Merchant
            MerchantUser.objects.create(
                user=user,
                company_name=kwargs.get('company_name', 'Test Company'),
                gst_details=kwargs.get('gst_details', 'GST123'),
                address=kwargs.get('address', 'Test Address')
            )
        elif user_type == 2:  # Staff
            StaffUser.objects.create(user=user)
        elif user_type == 4:  # Customer  
            CustomerUser.objects.create(user=user)
            
        return user
    return _create_user

@pytest.fixture
def create_test_category():
    """Factory for creating test categories."""
    def _create_category(title="Test Category", description="Test Description"):
        from DjangoEcommerceApp.models import Categories
        return Categories.objects.create(
            title=title,
            description=description
        )
    return _create_category

@pytest.fixture
def create_test_product():
    """Factory for creating test products."""
    def _create_product(merchant_user, category, title="Test Product"):
        from DjangoEcommerceApp.models import Product
        return Product.objects.create(
            title=title,
            merchant=merchant_user,
            category=category,
            price=100.0,
            stock=10
        )
    return _create_product

# IMPORTANT TESTING PATTERNS:
# 1. ALWAYS use @pytest.mark.django_db for database tests
# 2. Use django_client for views requiring sessions
# 3. Use SimpleUploadedFile for file uploads, NEVER set request.FILES
# 4. Create complete test data hierarchies
# 5. Use unique usernames/emails to avoid integrity errors

# Override settings for file upload tests
from django.test import override_settings

# Example test pattern:
@pytest.mark.django_db
def example_test_with_database():
    \"\"\"Example test showing proper Django testing patterns.\"\"\"
    # Setup complete test data
    user = create_test_user('testuser', 'test@example.com', 3)
    category = create_test_category()
    product = create_test_product(user.merchantuser, category)
    
    # Test with client
    client = django_client()
    client.force_login(user)
    response = client.get('/some-url/')
    assert response.status_code == 200

# Example file upload test:
@pytest.mark.django_db  
def example_file_upload_test(sample_uploaded_file):
    \"\"\"Example test showing proper file upload patterns.\"\"\"
    client = django_client()
    
    # CORRECT: Use SimpleUploadedFile in POST data
    response = client.post('/upload/', {
        'file': sample_uploaded_file
    })
    
    # NEVER do this: request.FILES = {'file': file} - it's read-only!
''',
        "flask": universal_scaffold + '''
# Flask-specific imports
try:
    from flask import Flask, request, session, g, jsonify
    from flask.testing import FlaskClient
    HAS_FLASK = True
except ImportError:
    HAS_FLASK = False

@pytest.fixture
def flask_app():
    """Flask application fixture."""
    if not HAS_FLASK:
        pytest.skip("Flask not available")
    
    try:
        # Try to import actual Flask app
        app = safe_import('app', 'app') or safe_import('application', 'app') or safe_import('main', 'app')
        if app and isinstance(app, Flask):
            app.config['TESTING'] = True
            return app
    except:
        pass
    
    # Fallback to creating test app
    app = Flask(__name__)
    app.config['TESTING'] = True
    return app

@pytest.fixture
def flask_client(flask_app):
    """Flask test client."""
    return flask_app.test_client()
''',
        "fastapi": universal_scaffold + '''
# FastAPI-specific imports
try:
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

@pytest.fixture
def fastapi_app():
    """FastAPI application fixture."""
    if not HAS_FASTAPI:
        pytest.skip("FastAPI not available")
    
    try:
        # Try to import actual FastAPI app
        app = safe_import('main', 'app') or safe_import('app', 'app') or safe_import('application', 'app')
        if app and isinstance(app, FastAPI):
            return app
    except:
        pass
    
    # Fallback to creating test app
    return FastAPI()

@pytest.fixture
def fastapi_client(fastapi_app):
    """FastAPI test client."""
    return TestClient(fastapi_app)
'''
    }
    
    return framework_scaffolds.get(framework, universal_scaffold)

def _get_framework_instructions(framework: str, kind: str) -> str:
    """Get framework-specific test generation instructions with safe fallback."""
    framework_instructions = FRAMEWORK_INSTRUCTIONS.get(
        framework, 
        FRAMEWORK_INSTRUCTIONS["vanilla"]  # Safe fallback to vanilla
    )
    return framework_instructions.get(kind, FRAMEWORK_INSTRUCTIONS["vanilla"]["unit"])

def targets_count(compact: Dict[str, Any], kind: str) -> int:
    functions = compact.get("functions", [])
    classes = compact.get("classes", [])
    methods = compact.get("methods", [])
    routes = compact.get("routes", [])
    
    if kind == "unit":
        return len(functions) + len(classes) + len(methods)
    if kind == "e2e":
        return len(routes)
    return max(len(functions) + len(classes) + len(methods), len(routes))

def files_per_kind(compact: Dict[str, Any], kind: str) -> int:
    """Distribute ALL targets across appropriate number of files."""
    total_targets = targets_count(compact, kind)
    if total_targets == 0:
        return 0
    
    # Increase targets per file to ensure comprehensive coverage
    targets_per_file = 30  # Reduced to generate more test methods per target
    
    if kind == "unit":
        return max(1, (total_targets + targets_per_file - 1) // targets_per_file)
    elif kind == "e2e":
        return max(1, (total_targets + 19) // 20)
    else:
        return max(1, (total_targets + 29) // 30)

def create_strategic_groups(targets: List[Dict[str, Any]], num_groups: int) -> List[List[Dict[str, Any]]]:
    if not targets or num_groups <= 0:
        return []
    
    if len(targets) <= num_groups:
        return [[t] for t in targets]
    
    # Group by file for better test organization
    file_groups = {}
    for target in targets:
        file_path = target.get("file", "unknown")
        if file_path not in file_groups:
            file_groups[file_path] = []
        file_groups[file_path].append(target)
    
    groups = [[] for _ in range(num_groups)]
    group_index = 0
    
    for file_targets in file_groups.values():
        for target in file_targets:
            groups[group_index].append(target)
            group_index = (group_index + 1) % num_groups
    
    return [g for g in groups if g]

def focus_for(compact: Dict[str, Any], kind: str, shard_idx: int, total_shards: int) -> Tuple[str, List[str], List[Dict[str, Any]]]:
    functions = compact.get("functions", [])
    classes = compact.get("classes", [])
    methods = compact.get("methods", [])
    routes = compact.get("routes", [])
    
    if kind == "unit":
        target_list = functions + classes + methods
    elif kind == "e2e":
        target_list = routes
    else:
        target_list = routes if routes else (functions + classes + methods)
    
    groups = create_strategic_groups(target_list, total_shards)
    shard_targets = groups[shard_idx] if 0 <= shard_idx < len(groups) else []
    
    target_names: List[str] = []
    for t in shard_targets:
        name = t.get("name") or t.get("handler")
        if name:
            target_names.append(name)
    
    focus_label = ", ".join(target_names) if target_names else "(none)"
    
    return focus_label, target_names, shard_targets

def build_prompt(kind: str, compact_json: str, focus_label: str, shard: int, total: int,
                 compact: Dict[str, Any], context: str = "", framework: str = "vanilla") -> List[Dict[str, str]]:
    """Build framework-aware prompt for test generation."""
    
    # Get framework-specific instructions with safe fallback
    framework_instructions = _get_framework_instructions(framework, kind)
    framework_scaffold = _get_framework_scaffold(framework)
    
    max_ctx = 60000
    trimmed_context = context[:max_ctx] if context else ""
    
    # Add specific guidance for Django based on common errors
    django_specific_guidance = ""
    if framework == "django":
        django_specific_guidance = f"""

DJANGO-SPECIFIC CRITICAL FIXES REQUIRED:

1. DATABASE ACCESS: EVERY test must use @pytest.mark.django_db
2. MIDDLEWARE: Use proper middleware initialization with get_response
3. FILE UPLOADS: Use SimpleUploadedFile, NEVER set request.FILES directly
4. TEST DATA: Create COMPLETE hierarchies (users → profiles → categories → products)
5. UNIQUE DATA: Use unique usernames/emails to avoid integrity errors
6. URLS: Verify URL names exist in the project before using reverse()
7. MODEL RELATIONSHIPS: Ensure all related objects exist before testing

COMMON ERROR FIXES:
- Database access: Add @pytest.mark.django_db to EVERY test
- SessionMiddleware: Initialize with get_response=lambda x: x
- FILES attribute: Use SimpleUploadedFile in POST data, don't set request.FILES
- Integrity errors: Use unique usernames like 'testuser_{shard}_{random_suffix}'
- Missing relationships: Create MerchantUser for merchant users, etc.
- URL reverses: Check that URL names exist in urls.py

TEST DATA PATTERN:
@pytest.mark.django_db
def test_example():
    # 1. Create user with profile
    user = CustomUser.objects.create(username='unique_username', user_type=3)
    merchant = MerchantUser.objects.create(user=user, company_name='Test Co')
    
    # 2. Create categories
    category = Categories.objects.create(title='Electronics')
    
    # 3. Create product  
    product = Product.objects.create(merchant=merchant, category=category, ...)
    
    # 4. Test with proper client
    client = Client()
    client.force_login(user)
    response = client.get('/url/')

FILE UPLOAD PATTERN:
from django.core.files.uploadedfile import SimpleUploadedFile

file = SimpleUploadedFile('test.jpg', b'content', 'image/jpeg')
response = client.post('/upload/', {{'file': file}})
# NEVER: request.FILES = {{'file': file}} - this causes AttributeError
"""

    user_content = f"""
FRAMEWORK-AWARE {kind.upper()} TEST GENERATION - FILE {shard + 1}/{total}
DETECTED FRAMEWORK: {framework.upper()}

{framework_instructions}

{django_specific_guidance if framework == 'django' else ''}

CRITICAL REQUIREMENTS FOR 95%+ COVERAGE:
1. Generate 5-8 test methods for EACH function/class/route
2. Test ALL code branches (if/else, try/except, loops)
3. Test edge cases: None, empty strings, zero, negative numbers, large numbers
4. Test error conditions: exceptions, validation failures, missing data
5. Use parametrize to test multiple input combinations
6. Test ALL public methods and properties
7. Use REAL imports - import actual code from the project
8. DO NOT create stubs or mocks for internal code
9. Only mock external dependencies (APIs, databases, network)
10. Ensure all imports are real and executable

COVERAGE OPTIMIZATION PATTERNS:
1. Test happy path (normal inputs, expected outputs)
2. Test sad path (invalid inputs, error conditions)
3. Test edge cases (boundary values, empty data, None)
4. Test all branches (if/else, match/case, exception handling)
5. Use @pytest.mark.parametrize for multiple scenarios

FOCUS TARGETS: {focus_label}

PROJECT ANALYSIS: {compact_json}

FULL CODE CONTEXT: {trimmed_context}

FRAMEWORK-SPECIFIC SCAFFOLD: {framework_scaffold}

GENERATE COMPREHENSIVE TESTS:
- Work with {framework.upper()} framework specifics
- Use real imports from the project
- Target 95%+ line and branch coverage
- Generate 5-8 test methods per target
- Test all code paths and edge cases
- Fix all common framework-specific errors
""".strip()
  
    return [
        {"role": "system", "content": SYSTEM_MIN},
        {"role": "user", "content": user_content},
    ]