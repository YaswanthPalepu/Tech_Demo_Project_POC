# src/gen/conftest_text.py - UPDATED with automatic Django app discovery
def conftest_text() -> str:
    """Repo-agnostic conftest that FORCES REAL IMPORTS for maximum coverage."""
    return '''"""
Professional pytest configuration for AI-generated tests.
CRITICAL: REAL imports ONLY - stubs disabled for 95%+ coverage.
Tests execute actual source code to achieve 95%+ coverage.
UNIVERSAL: Supports any Python framework and project structure.
"""

import os
import sys
import warnings
import builtins
import random
import types
import importlib
import inspect
import pytest
import asyncio
from unittest.mock import patch

# ---------------- General test env ----------------
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=PendingDeprecationWarning)
warnings.filterwarnings("ignore", category=UserWarning, module="pydantic")
os.environ.setdefault("TESTING", "true")
os.environ.setdefault("DATABASE_URL", "sqlite:///./test.db")
os.environ.setdefault("LOG_LEVEL", "ERROR")

# Insert TARGET_ROOT if provided
TARGET_ROOT = os.environ.get("TARGET_ROOT", "")
if TARGET_ROOT and TARGET_ROOT not in sys.path:
    sys.path.insert(0, TARGET_ROOT)

# UNIVERSAL: Enhanced framework auto-detection with Django priority
def _auto_detect_framework():
    """Auto-detect the primary framework used in the project with Django priority."""
    framework_indicators = {
        "django": ["django", "Django", "models.Model", "INSTALLED_APPS"],  # Django first
        "flask": ["Flask", "flask", "FlaskApp"],
        "fastapi": ["FastAPI", "fastapi", "APIRouter"],
        "starlette": ["Starlette", "starlette"],
        "tornado": ["tornado", "Tornado", "RequestHandler"],
        "bottle": ["bottle", "Bottle"],
        "pyramid": ["pyramid", "Pyramid"],
        "sanic": ["sanic", "Sanic"],
        "chalice": ["chalice", "Chalice"]
    }
    
    # Check for Django first (most common and requires early setup)
    for indicator in framework_indicators["django"]:
        try:
            __import__(indicator.split('.')[0])
            print(f" UNIVERSAL: Detected Django framework")
            return "django"
        except ImportError:
            continue
    
    # Check other frameworks
    for framework, indicators in framework_indicators.items():
        if framework == "django":
            continue  # Already checked
        for indicator in indicators:
            try:
                __import__(indicator.split('.')[0])
                print(f" UNIVERSAL: Detected {framework} framework")
                return framework
            except ImportError:
                continue
    
    print(" UNIVERSAL: No specific framework detected, using vanilla Python")
    return "vanilla"

FRAMEWORK = _auto_detect_framework()

# CRITICAL: Enhanced Django setup with automatic app discovery
if FRAMEWORK == "django":
    print(" UNIVERSAL: Setting up Django environment with automatic app discovery...")
    try:
        import django
        from django.conf import settings
        
        # Configure Django settings if not already configured
        if not settings.configured:
            print(" UNIVERSAL: Configuring Django settings with automatic app discovery...")
            
            # Try to find settings module
            settings_module = os.environ.get('DJANGO_SETTINGS_MODULE')
            if not settings_module:
                # Look for settings.py in the project
                import glob
                search_root = TARGET_ROOT if TARGET_ROOT else '.'
                settings_files = glob.glob(f'{search_root}/**/settings.py', recursive=True)
                for sf in settings_files:
                    if 'venv' not in sf and 'site-packages' not in sf:
                        # Convert path to module
                        rel_path = sf
                        if TARGET_ROOT:
                            rel_path = sf.replace(TARGET_ROOT, '').lstrip('/')
                        settings_module = rel_path.replace('/', '.').replace('.py', '')
                        print(f" UNIVERSAL: Found settings module: {settings_module}")
                        break
            
            if settings_module:
                os.environ['DJANGO_SETTINGS_MODULE'] = settings_module
                print(f" UNIVERSAL: Set DJANGO_SETTINGS_MODULE to {settings_module}")
            else:
                # AUTO-DISCOVER Django apps in the project
                print(" UNIVERSAL: Auto-discovering Django apps...")
                installed_apps = [
                    'django.contrib.auth',
                    'django.contrib.contenttypes',
                    'django.contrib.sessions',
                    'django.contrib.admin',
                    'django.contrib.messages',
                ]
                
                # Discover project apps by looking for apps.py files
                import glob
                search_root = TARGET_ROOT if TARGET_ROOT else '.'
                apps_py_files = glob.glob(f'{search_root}/**/apps.py', recursive=True)
                
                for app_file in apps_py_files:
                    if 'venv' not in app_file and 'site-packages' not in app_file:
                        # Extract app name from path
                        if TARGET_ROOT:
                            app_path = app_file.replace(TARGET_ROOT, '').lstrip('/')
                        else:
                            app_path = app_file
                        
                        # Convert path to Python module path
                        app_module = app_path.replace('/', '.').replace('.py', '')
                        # Remove the .apps from the end to get the app name
                        app_name = app_module.rsplit('.', 1)[0]
                        
                        if app_name not in installed_apps:
                            installed_apps.append(app_name)
                            print(f" UNIVERSAL: Discovered app: {app_name}")
                
                # Also look for common Django app patterns
                common_app_patterns = [
                    f'{search_root}/*/models.py',
                    f'{search_root}/*/admin.py',
                    f'{search_root}/*/views.py',
                ]
                
                for pattern in common_app_patterns:
                    for app_file in glob.glob(pattern, recursive=True):
                        if 'venv' not in app_file and 'site-packages' not in app_file:
                            # Extract directory name
                            app_dir = os.path.dirname(app_file)
                            if TARGET_ROOT:
                                app_dir = app_dir.replace(TARGET_ROOT, '').lstrip('/')
                            
                            app_name = app_dir.replace('/', '.')
                            if app_name and app_name not in installed_apps and not app_name.startswith('.'):
                                installed_apps.append(app_name)
                                print(f" UNIVERSAL: Discovered app from patterns: {app_name}")
                
                print(f UNIVERSAL: Configuring Django with {len(installed_apps)} apps: {installed_apps}")
                
                # Configure minimal Django settings for testing
                settings.configure(
                    DEBUG=True,
                    TESTING=True,
                    SECRET_KEY='test-secret-key-for-universal-testing-2024',
                    DATABASES={
                        "default": {
                            "ENGINE": "django.db.backends.sqlite3",
                            "NAME": ":memory:",
                        }
                    },
                    INSTALLED_APPS=installed_apps,
                    MIDDLEWARE=[
                        'django.middleware.security.SecurityMiddleware',
                        'django.contrib.sessions.middleware.SessionMiddleware',
                        'django.middleware.common.CommonMiddleware',
                        'django.middleware.csrf.CsrfViewMiddleware',
                        'django.contrib.auth.middleware.AuthenticationMiddleware',
                        'django.contrib.messages.middleware.MessageMiddleware',
                    ],
                    ROOT_URLCONF='',
                    USE_TZ=True,
                )
            
            # Setup Django
            django.setup()
            print(" UNIVERSAL: Django setup completed successfully")
            
    except Exception as e:
        print(f" UNIVERSAL: Django setup failed: {e}")
        # Continue without Django setup

# ---------------- Async Test Support ----------------
try:
    import pytest_asyncio
    ASYNC_SUPPORT = True
except ImportError:
    ASYNC_SUPPORT = False
    print(" pytest-asyncio not installed - async tests will be skipped")

@pytest.fixture
def event_loop():
    """Create an instance of the default event loop for each test case."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

# ---------------- EnhancedRenderer Definition ----------------
class EnhancedRenderer:
    """Enhanced renderer that always returns bytes - standalone implementation."""
    
    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs
        
    def render(self, data, accepted_media_type=None, renderer_context=None):
        """Render data to bytes with comprehensive error handling."""
        try:
            if isinstance(data, (bytes, bytearray)):
                return bytes(data)
            import json
            if isinstance(data, (dict, list)):
                return json.dumps(data).encode("utf-8")
            return str(data).encode("utf-8")
        except Exception:
            return b'{"error": "serialization_failed"}'

# ---------------- Database Test Isolation ----------------
@pytest.fixture(autouse=True)
def _database_isolation():
    """Auto-setup test environment with database isolation."""
    random.seed(42)
    
    # Use in-memory SQLite for tests to prevent real DB access
    os.environ['DATABASE_URL'] = 'sqlite:///:memory:'
    os.environ['TEST_DATABASE_URL'] = 'sqlite:///:memory:'
    
    # Setup test mode flags
    os.environ['TESTING'] = 'true'
    os.environ['ENV'] = 'test'
    os.environ['ENVIRONMENT'] = 'test'
    
    # Mock database operations to prevent real DB access
    with patch('sqlite3.connect'), \
         patch('sqlalchemy.create_engine'), \
         patch('django.db.connections'):
        yield
    
    # Cleanup
    if os.path.exists('test.db'):
        try:
            os.remove('test.db')
        except:
            pass

# ---------------- REAL IMPORTS ONLY - NO STUBS ----------------
# Stubs disabled to force real code execution for 95%+ coverage

# UNIVERSAL: Auto-detect and import real app for any framework
create_app = None
app_instance = None

try:
    # Framework-specific app detection
    if FRAMEWORK == "flask":
        # Try common Flask app patterns
        for module_path in ['app', 'application', 'main', 'server', 'api', 'backend']:
            for factory_name in ['create_app', 'app', 'application', 'get_app']:
                try:
                    mod = __import__(module_path)
                    if hasattr(mod, factory_name):
                        create_app = getattr(mod, factory_name)
                        if callable(create_app):
                            app_instance = create_app()
                        else:
                            app_instance = create_app
                        break
                except ImportError:
                    continue
            if create_app:
                break
        
        # Fallback to creating Flask app
        if not app_instance:
            try:
                from flask import Flask
                app_instance = Flask(__name__)
                app_instance.config['TESTING'] = True
            except ImportError:
                pass
    
    elif FRAMEWORK == "fastapi":
        # Try common FastAPI app patterns
        for module_path in ['main', 'app', 'api', 'server']:
            try:
                mod = __import__(module_path)
                if hasattr(mod, 'app'):
                    app_instance = getattr(mod, 'app')
                    break
            except ImportError:
                continue
        
        # Fallback to creating FastAPI app
        if not app_instance:
            try:
                from fastapi import FastAPI
                app_instance = FastAPI()
            except ImportError:
                pass
    
    elif FRAMEWORK == "django":
        # Django setup already handled above
        try:
            from django.test.utils import setup_test_environment, teardown_test_environment
            setup_test_environment_available = True
        except ImportError:
            setup_test_environment_available = False
    
    elif FRAMEWORK in ["starlette", "tornado", "bottle", "pyramid", "sanic", "chalice"]:
        # Try to import app for other frameworks
        for module_path in ['main', 'app', 'application']:
            try:
                mod = __import__(module_path)
                if hasattr(mod, 'app'):
                    app_instance = getattr(mod, 'app')
                    break
            except ImportError:
                continue

except Exception as e:
    print(f" UNIVERSAL: Could not auto-import app for {FRAMEWORK}: {e}")

# UNIVERSAL application fixture
@pytest.fixture(scope="session")
def app():
    """UNIVERSAL application fixture - REAL app only."""
    if app_instance:
        # Framework-specific context management
        if FRAMEWORK == "flask" and hasattr(app_instance, 'app_context'):
            ctx = app_instance.app_context()
            ctx.push()
            yield app_instance
            ctx.pop()
        elif FRAMEWORK == "django":
            if 'setup_test_environment_available' in locals() and setup_test_environment_available:
                setup_test_environment()
            yield app_instance
            if 'setup_test_environment_available' in locals() and setup_test_environment_available:
                teardown_test_environment()
        else:
            yield app_instance
        return
    
    # Fallback for vanilla Python or undetected frameworks
    yield None

# UNIVERSAL client fixture
@pytest.fixture
def client(app):
    """UNIVERSAL test client - REAL client only."""
    # Flask
    if FRAMEWORK == "flask" and hasattr(app, 'test_client'):
        return app.test_client()
    
    # FastAPI
    if FRAMEWORK == "fastapi":
        try:
            from fastapi.testclient import TestClient
            return TestClient(app)
        except ImportError:
            pass
    
    # Django
    if FRAMEWORK == "django":
        try:
            from django.test import Client as DjangoClient
            return DjangoClient()
        except ImportError:
            pass
    
    # Starlette
    if FRAMEWORK == "starlette":
        try:
            from starlette.testclient import TestClient
            return TestClient(app)
        except ImportError:
            pass
    
    # Fallback
    pytest.skip(f"No test client available for {FRAMEWORK}")

# ---------------- Database fixtures for real testing ----------------
@pytest.fixture(scope="session")
def db_setup():
    """Setup real database for testing."""
    if FRAMEWORK == "django":
        try:
            from django.core.management import call_command
            # Create tables for all installed apps
            call_command('migrate', '--run-syncdb', verbosity=0, interactive=False)
            print(" UNIVERSAL: Django test database setup completed")
        except Exception as e:
            print(f" UNIVERSAL: Django database setup failed: {e}")
            # If migrations fail, try creating tables directly
            try:
                from django.core.management import call_command
                call_command('migrate', '--run-syncdb', '--noinput', verbosity=0)
            except Exception as e2:
                print(f" UNIVERSAL: Django fallback database setup also failed: {e2}")
    yield

@pytest.fixture
def db(db_setup):
    """Database fixture with transaction rollback."""
    if FRAMEWORK == "django":
        try:
            from django.test import TestCase
            from django.db import transaction
            # Use Django's test database setup
            with transaction.atomic():
                sid = transaction.savepoint()
                yield
                transaction.savepoint_rollback(sid)
        except Exception as e:
            print(f" UNIVERSAL: Django transaction setup failed: {e}")
            yield
    else:
        yield

# Django-specific marker support
if FRAMEWORK == "django":
    def pytest_configure(config):
        """Register django_db marker."""
        config.addinivalue_line(
            "markers", "django_db: mark test to use Django database"
        )
    
    @pytest.fixture(autouse=True)
    def _django_db_marker(request, db):
        """Auto-apply db fixture when django_db marker is present."""
        marker = request.node.get_closest_marker('django_db')
        if marker:
            # db fixture already applied via parameter
            pass

# UNIVERSAL API client
@pytest.fixture
def api_client():
    """UNIVERSAL API client for testing REST endpoints."""
    # Django REST framework
    if FRAMEWORK == "django":
        try:
            from rest_framework.test import APIClient
            return APIClient()
        except ImportError:
            pass
    
    # FastAPI
    if FRAMEWORK == "fastapi":
        try:
            from fastapi.testclient import TestClient
            for module_path in ['main', 'app', 'api']:
                try:
                    mod = __import__(module_path)
                    if hasattr(mod, 'app'):
                        return TestClient(getattr(mod, 'app'))
                except ImportError:
                    continue
        except ImportError:
            pass
    
    # Fallback to regular client
    pytest.skip(f'No API client available for {FRAMEWORK}')

# UNIVERSAL test utilities
@pytest.fixture
def clean_environment(monkeypatch):
    """Reset environment for each test."""
    for var in ("DATABASE_URL", "REDIS_URL", "API_KEY", "SECRET_KEY"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("TESTING", "true")
    yield

@pytest.fixture
def mock_file_operations():
    """Mock file I/O for deterministic tests."""
    with patch("pathlib.Path.exists", return_value=True), \
         patch("pathlib.Path.read_text", return_value="mock content"), \
         patch("pathlib.Path.write_text"), \
         patch("os.makedirs"), \
         patch("shutil.rmtree"):
        yield

@pytest.fixture(params=[{}, {'key': 'value'}, {'nested': {'data': 'test'}}])
def various_data(request):
    """Parametrized fixture for testing with various data structures."""
    return request.param

@pytest.fixture(params=['', 'test', None, 123, True, [], {}])
def edge_case_values(request):
    """Parametrized fixture for edge case testing."""
    return request.param

@pytest.fixture
def sample_data():
    """Comprehensive sample data for all test scenarios."""
    return {
        "foo": "bar",
        "num": 123,
        "none": None,
        "username": "testuser",
        "email": "test@example.com",
        "password": "testpass123",
        "title": "Test Title",
        "description": "Test Description",
        "body": "Test Body Content",
        "slug": "test-slug",
        "tags": ["test", "coverage"],
        "is_active": True,
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }

@pytest.fixture
def mock_request():
    """Mock request object for testing views."""
    class MockRequest:
        def __init__(self):
            self.data = {}
            self.query_params = {}
            self.headers = {}
            self.method = 'GET'
            self.path = '/test'
            self.user = types.SimpleNamespace(id=1, username='testuser', is_authenticated=True)
            self.META = {}
            self.GET = {}
            self.POST = {}
            self.FILES = {}
            self.session = {}
    
    return MockRequest()

@pytest.fixture
def authenticated_user():
    """Mock authenticated user for testing."""
    user = types.SimpleNamespace()
    user.id = 1
    user.username = 'testuser'
    user.email = 'test@example.com'
    user.is_authenticated = True
    user.is_active = True
    user.is_staff = False
    user.is_superuser = False
    return user

# ---------------- Async Function Support ----------------
def run_async(coro):
    """Run async coroutine in sync context."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()

@pytest.fixture
def async_run():
    """Fixture to run async functions in tests."""
    return run_async

# UNIVERSAL coverage optimization
@pytest.fixture(scope="session", autouse=True)
def coverage_optimization():
    """Optimize environment for 95%+ coverage."""
    # Set coverage optimization flags
    os.environ['COVERAGE_OPTIMIZATION'] = 'true'
    os.environ['COVERAGE_TARGET'] = '95'
    os.environ['REAL_IMPORTS_ONLY'] = 'true'
    
    print(f" UNIVERSAL: Targeting 95%+ coverage for {FRAMEWORK} framework")
    print(f" UNIVERSAL: Real imports only - no stubs")
    
    yield
    
    # Cleanup
    for var in ['COVERAGE_OPTIMIZATION', 'COVERAGE_TARGET', 'REAL_IMPORTS_ONLY']:
        os.environ.pop(var, None)

# CRITICAL: Import safety for Django projects
if FRAMEWORK == "django":
    @pytest.fixture(scope="session", autouse=True)
    def django_import_safety():
        """Ensure Django imports are safe during test collection."""
        print(" UNIVERSAL: Django import safety enabled")
        yield
'''